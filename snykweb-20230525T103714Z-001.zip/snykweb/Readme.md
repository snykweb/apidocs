


## Readme


```
pip install mkdocs
```

to install `mkdocs` dependency


````
mkdocs serve
```

to build MKdocs documentation with the server