## Take User Input


```
get_user_input(input_name:str) -> str
```
Returns the user input value for the specified input name.

```
get_query_string() -> str
```
Returns the full query string of the current URL.

```
get_request_headers() -> dict
```
Returns a dictionary containing all the request headers.

```
get_post_data() -> dict
```
Returns a dictionary containing all the POST data.

```
get_file_upload(file_input_name:str) -> file
```
Returns the file uploaded by the user for the specified file input name.


## Database Access
```
connect_to_database() -> db_connection
```
Returns a connection object to the configured database.

```
execute_sql_query(query:str) -> query_result
```
Executes the given SQL query and returns the result.

```
execute_stored_procedure(proc_name:str, params:dict) -> proc_result
```
Executes the specified stored procedure with the given parameters and returns the result.

```
execute_safesql_query(query:str,parameter) -> query_result
```
Executes the given SQL query and returns the result. Does automatic escaping



## File Access
```
read_file(file_path:str) -> str
```
Reads the contents of the specified file and returns it as a string.
```
write_file(content:str, filepath:str) -> None
```
Writes the given content to the specified file.
```
delete_file(file_path:str) -> None
```
Deletes the specified file.

## Common Functions
```
redirect(url:str) -> None
```
Redirects the user to the specified URL.

```
set_cookie(cookie_name:str, cookie_value:str) -> None
```
Sets a cookie with the given name and value.

```
get_cookie(cookie_name:str) -> str
```
Returns the value of the cookie with the given name.

```
clear_cookie(cookie_name:str) -> None
```
Clears the cookie with the given name.

```
log(message:str) -> None
```
Logs the given message to the server log.

```
send_email(to:str, subject:str, message:str) -> None
```
Sends an email to the specified recipient with the given subject and message.




## User Authentication
```
login(username:str, password:str) -> bool
```
Authenticates the user with the given username and password and returns a boolean indicating whether the authentication was successful.

```
logout() -> None
```
Logs out the current user.

```
get_user_info() -> dict
```
Returns a dictionary containing information about the currently logged in user.


## Form Handling
```
validate_form(form_data:dict, validation_rules:dict) -> dict
```
Validates the given form data against the specified validation rules and returns a dictionary containing any validation errors.

```
render_form(template:str, form_data:dict) -> str
```
Renders the specified template with the given form data and returns the resulting HTML.

```
submit_form(form_data:dict) -> None
```
Submits the given form data to the server.


##  Response Handling

```
render_template(template:str, context:dict) -> str
```
Renders the specified template with the given context and returns the resulting HTML.

```
send_json(data:dict) -> None
```
Sends the specified data as a JSON response.

```
send_file(file_path:str) -> None
```
Sends the specified file as a response.


## Security
```
sanitize_input(input:str) -> str
```
Sanitizes the given input to prevent cross-site scripting (XSS) attacks. Escapes < and > to its corresponding HTML entity.

```
hash_password(password:str,algorithm:str) -> str
```
Hashes the given password for secure storage. A hashing algorithm can also be specified. Default is md5.

```
verify_password(password:str, hash:str) -> bool
```
Verifies the given password against the specified hash and returns a boolean indicating whether the verification was successful.



## Utilities

```
generate_random_string(length:int) -> str
```
Generates a random string of the specified length. A length must be specified

```
get_current_time() -> datetime
```
Returns the current date and time.

```
sleep(seconds:float) -> None
```
Pauses the execution of the program for the specified number of seconds.



## Logging and Debugging

```
Logging(filepath:str) -> None
```
Generates a logging constructor with a filepath to save the log data to.

```
debug(message:str) -> None
```
Logs a debug message to the server log.

```
info(message:str) -> None
```
Logs an informational message to the server log.

```
warn(message:str) -> None
```
Logs a warning message to the server log.

```
error(message:str) -> None
```

Logs an error message to the server log.


## HTTP Request Handling
```
get(url:str, params:dict=None, headers:dict=None) -> dict
```
Sends an HTTP GET request to the specified URL with the specified query parameters and headers, and returns the response as a dictionary.

```
post(url:str, data:dict=None, headers:dict=None) -> dict
```
Sends an HTTP POST request to the specified URL with the specified data and headers, and returns the response as a dictionary.

```
put(url:str, data:dict=None, headers:dict=None) -> dict
```
Sends an HTTP PUT request to the specified URL with the specified data and headers, and returns the response as a dictionary.

```
delete(url:str, data:dict=None, headers:dict=None) -> dict
```
Sends an HTTP DELETE request to the specified URL with the specified data and headers, and returns the response as a dictionary.

```
getuseragent(url:str, data:dict=None, headers:dict=None) -> dict
```
Sends an HTTP DELETE request to the specified URL with the specified data and headers, and returns the response as a dictionary.


## Caching
```
set_cache(key:str, value:str, ttl:int=None) -> None
```
Sets a value in the cache with the specified key and optional time-to-live (TTL).

```
get_cache(key:str) -> str
```
Retrieves the value from the cache with the specified key.

```
delete_cache(key:str) -> None
```
Deletes the value from the cache with the specified key.


## File Storage
```
upload_file(file:file, folder:str=None) -> str
```
Uploads the specified file to the server and returns the URL where the file can be accessed.

```
download_file(url:str) -> file
```
Downloads the file from the specified URL and returns it as a file object.

```
delete_file_from_server(url:str) -> None
```
Deletes the file from the server at the specified URL.



## Email Handling
```
send_email_with_attachment(to:str, subject:str, message:str, attachment:str) -> None
```
Sends an email with the specified subject, message, and attachment to the specified recipient.

```
send_email_template(to:str, template:str, context:dict) -> None
```
Renders the specified email template with the given context and sends the resulting email to the specified recipient.




## Low level Access API

Allows access to the underlying C API

```
execute_c_function(function_name: str, args: List[Any]) -> Any
```

Executes the specified C function with the given arguments and returns the result.

* function_name: The name of the C function to execute.
* args: A list of arguments to pass to the C function.

Example:

```
HTTP POST /execute-c-function
Content-Type: application/json

{
    "function_name": "add_numbers",
    "args": [1, 2, 3]
}

Response:

{
    "result": 6
}
```


```
create_socket(socket_type: str, port: int) -> str
```
Creates a new socket of the specified type and port and returns a unique socket identifier.

* socket_type: The type of socket to create (e.g., "TCP", "UDP").
8 port: The port number to use for the socket.


Example:
```
HTTP POST /create-socket
Content-Type: application/json

{
    "socket_type": "TCP",
    "port": 80
}

Response:

{
    "socket_id": "1234"
}
```

```
send_data(socket_id: int, data: bytes,flags: int) -> None
```

Sends the specified data over the socket with the given identifier.

* socket_id: The identifier of the socket to use for sending data.
* data: The data to send, encoded as bytes.

Example:

```
HTTP POST /send-data
Content-Type: application/json

{
    "socket_id": 1234,
    "data": "Hello, world!".encode("utf-8")
}

Response:

HTTP 200 OK
```

```
recv_data(socket_id: int, data: bytes, size: length, flags: int) -> None
```

Recieves the specified data over the socket with the given identifier and stores it in a buffer. 

* socket_id: The identifier of the socket to use for sending data.
* data: The data recieved, encoded as bytes.
* length: The length in bytes of the buffer. If the MSG_CONNTERM flag is set, the length of the buffer must be zero.
* flags: The flags parameter is set by specifying one or more of the following flags. Can be empty. If more than one flag is specified, the logical OR operator ( | ) must be used to separate them. The MSG_CONNTERM flag is mutually exclusive with other flags.
