# SnykWeb API Documentation

For full documentation visit [https://snykweb.github.io](https://snykweb.github.io).

### Commands from SnykWeb CLI

* `snykweb new [dir-name]` - Create a new project.
* `snykweb serve` - Start the live-reloading docs server.
* `snykweb build` - Build the documentation site.
* `snykweb -h` - Print help message and exit.


