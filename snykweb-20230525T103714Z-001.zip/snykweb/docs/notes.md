

# Release Notes

## SnykWeb Release Notes - v2.0.0

### Bug Fixes and Performance Optimizations

In addition to the new features and improvements, SnykWeb includes various bug fixes and performance optimizations. These include:

* Fixed a bug where database connections were not properly closed after use
* Improved the performance of the file storage system for large files
* Fixed a bug where certain HTTP request headers were not being properly parsed
* A buffer overflow vulnerability exists in `recv_data` function, this has been mitigated by not using `sprintf` and using `memcpy` instead of `strcpy`
* Remove usage of `strcopy` to `strncopy` in `create_socket` 

### Known Issues

There are currently no known issues in this release.

### Upgrade Instructions

To upgrade to SnykWeb v2.0.0, simply replace the existing framework files with the new version. Note that some changes may be required to your web application code to take advantage of the new features and improvements.

### Conclusion

Any problems open a bug report

## SnykWeb Release Notes - v1.0.0


### Overview

This release of SnykWeb introduces several new features and improvements, including:
* Support for user authentication and authorization
* Enhanced file storage capabilities
* Improved logging and error handling
* Various bug fixes and performance optimizations

## New Features

SnykWeb now includes built-in support for user authentication and authorization, allowing developers to easily secure their web applications. The framework includes a flexible and customizable authentication system, with support for various authentication methods such as username/password, social logins, and multi-factor authentication.

SnykWeb's file storage capabilities have been enhanced to provide greater flexibility and ease of use. Developers can now upload and download files directly from the framework, with support for various file formats and sizes. The framework also includes a powerful file management system, allowing developers to easily organize and manage their files.

SnykWeb's logging and error handling capabilities have been improved, with support for customizable log levels, error messages, and more. The framework includes built-in support for popular logging libraries such as Log4j and Logback, and can be easily configured to meet the needs of any web application.


In addition to the new features and improvements, SnykWeb includes various bug fixes and performance optimizations. These include:

    Fixed a bug where database connections were not properly closed after use
    Improved the performance of the file storage system for large files
    Fixed a bug where certain HTTP request headers were not being properly parsed

## Known Issues

There are currently no known issues in this release.

## Upgrade Instructions

To upgrade to SnykWeb v1.0.0, simply replace the existing framework files with the new version. Note that some changes may be required to your web application code to take advantage of the new features and improvements.

## Conclusion

We hope that this release of SnykWeb will provide developers with the tools and capabilities they need to build secure and scalable web applications. As always, we welcome feedback and suggestions for future releases, and encourage developers to contribute to the project on our GitHub page.ition where if an SnykWeb very large stack of routes, and all of those routes are sync (call next() synchronously), then the request processing may hang.



